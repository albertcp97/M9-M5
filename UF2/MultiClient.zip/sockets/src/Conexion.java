
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;


public class Conexion 
{
	PrintWriter out;
	BufferedReader in;
		
	public Conexion(Socket socket, int port) throws IOException 
	{
		out = new PrintWriter(socket.getOutputStream(),true);
		in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
	}
	
	public Conexion(ServerSocket serversocket) throws IOException 
	{
		Socket clientsocket = serversocket.accept();
		out = new PrintWriter(clientsocket.getOutputStream(),true);
		in = new BufferedReader(new InputStreamReader(clientsocket.getInputStream()));
	}
	
	public void Cerrar() throws IOException 
	{
		out.close();
		in.close();
	}
	
	public void Enviar(String mensaje) 
	{
		System.out.println("Enviando "+mensaje);
		out.println(mensaje);
	}
	
	public String Recibir() throws IOException 
	{
		return in.readLine();
	}
	
	public void Recibir(String respuesta) throws IOException, ConnectionExcep
	{
		String res = in.readLine();
		System.out.println("Recibiendo "+res);
		if(!res.equals(res))
			throw new ConnectionExcep("Esperar " + respuesta + " recibir " + res);
	}
	
	public void EnviarRecibir(String mensaje, String respuesta) throws IOException, ConnectionExcep 
	{
		Enviar(mensaje);
		Recibir(respuesta);
	}
	
	public void RecibirEnviar(String mensaje, String respuesta) throws IOException, ConnectionExcep 
	{
		Recibir(mensaje);
		Enviar(respuesta);
	}
	
}
