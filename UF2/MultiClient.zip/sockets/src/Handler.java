import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Handler implements Runnable{
	private Socket m_socket;
	private Conexion m_sif;
	Server m_server;
	
	private String m_nickname;
	
 public Handler(Socket socket, Server s) throws IOException {
	 m_socket=socket;
	 m_server= s;
	 m_sif = new Conexion(socket,60009);
 }
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		try
        {System.out.println("Enviar");
        	//connection
        	m_sif.EnviarRecibir("Hola","ACK");
        	
        	
        }catch (Exception e) {
			// TODO: handle exception
		}
		while (true) {
			
			
		}
	}

}
