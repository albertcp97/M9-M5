
public class ConnectionExcep extends Exception 
{
	public ConnectionExcep(String error) 
	{
		super(error);
	}
}
