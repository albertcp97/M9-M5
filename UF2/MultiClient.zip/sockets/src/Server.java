import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Server implements Runnable{

	public static String palabra;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String respuestaCliente;
		String respuestaServer;
		int port = 60009;
		ExecutorService executor = Executors.newCachedThreadPool();
		
		Server s= new Server();
		try 
		{
			ServerSocket serversocket = new ServerSocket(port);
			//executor
			Conexion connect = new Conexion(serversocket);
			
			executor.execute(s);
			while(true)
        	{
	        	Socket clientSocket = serversocket.accept();
	        	
	        	
	        	Handler h= new Handler(clientSocket, s);
	        	
	        	
	        	executor.execute(h);
	        	
	        	/*try
	        	{
	            	executor.execute(handler);
	        	}catch(RejectedExecutionException e)
	        	{
	        		System.err.println("ERROR CREATING THREAD");
	        		clientSocket.close();
	        	}*/
        	}
			
		}catch (IOException e) {
				e.printStackTrace();
			} 
			
	}

	private static String Comparar(String recibir) {
		// TODO Auto-generated method stub
		String respuesta="";
		String s[]= recibir.split("");
		
		for(int i=0; i<s.length;i++)
		{	System.out.println(s[i]);
			if(palabra.contains(s[i]))
				respuesta+="c";
			else
				respuesta+="f";
		}
		
		return respuesta;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}
	
}
