import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;


public class Client {

	public static void main(String[] args)   {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String clientResponse;
		String serverResponse;
		
        String hostName = "localhost";
        int portNumber = 60009;

        try
        {
            Socket echoSocket = new Socket(hostName, portNumber);
        	Conexion connect = new Conexion(echoSocket, portNumber);	
        	
        	System.out.println("Conectado");
        	System.out.println(connect.Recibir());
        	//System.out.println(connect.Recibir());
        	
        	//connect.Enviar(sc.nextLine());
        	//System.out.println(connect.Recibir());
            	
        	connect.Cerrar();
				
				
			
        }catch (IOException e) {
			e.printStackTrace();
		} 
	}

}
