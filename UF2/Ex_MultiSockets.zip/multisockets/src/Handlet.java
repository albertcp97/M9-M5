import java.io.IOException;
import java.net.Socket;

public class Handlet implements Runnable{
	private Socket m_socket;
	private SocketInterface m_sif;
	private Srv m_server;
	
	public Handlet(Socket m_socket, Srv m_server) throws IOException {
		super();
		this.m_socket = m_socket;
		this.m_server = m_server;
		
		m_sif = new SocketInterface(m_socket);
		m_sif.verbose = true;
		m_sif.verbosePreamble = m_socket.getInetAddress() + " -> ";
	}
	private String m_nickname;
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		m_sif.send("Hola Picolo");
		System.err.println("Un cliente se conecto");

		if(m_server.conectarse()) {
		
			
			
			synchronized(m_server.loby)
			{
				try {
					System.out.println("Esperando");
					m_server.loby.wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
System.out.println("AQUI LLEGO");
			m_sif.send("Escoge nick");
			try {
				m_nickname=m_sif.receive();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			if(m_server.comprobarNick(m_nickname)) {
				
				do {
					m_sif.send("no");
					try {
						m_nickname=m_sif.receive();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}while(m_server.comprobarNick(m_nickname));
			}
			m_sif.send("ok");
			try {
				System.out.println(m_sif.receive());
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}			
			
			synchronized(m_server.gameStart)
			{
				m_server.playerReady();
				try {
					m_server.gameStart.wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			m_sif.send("dispara");
			try {
				System.out.println(m_sif.receive());
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
