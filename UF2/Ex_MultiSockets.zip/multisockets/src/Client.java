import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {
	
	public static void main(String[] args) throws UnknownHostException, IOException, CommunicationProtocolException
	{
		SocketInterface sif = null;
		String hostName = "localhost";
		int portNumber = 60009;

		boolean continuePlaying = true;
		Scanner sc= new Scanner(System.in);
		
		Socket socket = new Socket(hostName, portNumber);
        BufferedReader scanner = new BufferedReader(new InputStreamReader(System.in));
		sif = new SocketInterface(socket);
		sif.verbose = true;
		
		System.out.println(sif.receive());
		System.out.println(sif.receive());
		
		String nkname="";
		String out="";
		do {

			System.out.println("Escribe algo2");
			nkname=sc.nextLine();
			out=sif.sendAndReceive(nkname);
		}while(out.equals("no"));
		System.out.println("Escribe algo");
		sif.send(sc.nextLine());
		out=sif.receiveAndSend("hola caracola");
		
	}
}
